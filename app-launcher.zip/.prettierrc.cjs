module.exports = {
    trailingComma: 'es5',
    tabWidth: 2,
    semi: true,
    singleQuote: true,
    jsxSingleQuote: true,
    printWidth: 100,
    bracketSpacing: true,
    arrowParens: 'always',
}
